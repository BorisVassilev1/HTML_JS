
function update() {
    
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    window.requestAnimationFrame(draw);
}


window.requestAnimationFrame(draw);
setInterval(update, 10);

